package edu.uef.thithuchanh;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private TextView selectedDrinkTextView;
    private List<String> drink;
    private List<String> selectedDrink;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView drinkListView = findViewById(R.id.drinkListView);
        selectedDrinkTextView = findViewById(R.id.selectedDrinkTextView);

        drink = Arrays.asList(
                "Bread",
                "Cherry Cheesecake",
                "Gingerbread House",
                "Hamburger",
                "Sunny Side Up Eggs",
                "Crab Cake",
                "Round Sticky Rice Cake",
                "Snail Rice Noodle",
                "Round Sticky Rice Cake",
                "Soya Bean Cake"
        );

        List<Integer> drinkImages = Arrays.asList(
                R.drawable.beer,
                R.drawable.lemonade,
                R.drawable.coconutcocktail,
                R.drawable.milkshake,
                R.drawable.orangejuice
        );

        // Reverse the order of dishes starting from index 5
        Collections.reverse(drink.subList(5, drink.size()));
        Collections.reverse(drinkImages.subList(5, drinkImages.size()));
        

        drinkListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String selectedDish = drink.get(position);
                selectedDrink.add(selectedDish);

                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < selectedDrink.size(); i++) {
                    sb.append("Dish ").append(i + 1).append(": ").append(selectedDrink.get(i));
                    if (i != selectedDrink.size() - 1) {
                        sb.append("\n");
                    }
                }

                selectedDrinkTextView.setText(sb.toString());
            }
        });
    }
}